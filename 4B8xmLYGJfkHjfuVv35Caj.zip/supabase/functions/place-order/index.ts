import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const OWNER_EMAIL = 'bossadit6204535@gmail.com';

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { orderData } = await req.json();
    
    console.log('Received order:', orderData);

    // Create Supabase client with service role
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Save order to database
    const { data: order, error: dbError } = await supabaseAdmin
      .from('orders')
      .insert({
        id: orderData.id,
        customer_name: orderData.customerName,
        customer_phone: orderData.phone,
        customer_address: orderData.address,
        items: orderData.items,
        total_amount: orderData.totalAmount,
        delivery_time: orderData.deliveryTime,
        status: orderData.status,
        order_date: orderData.orderDate,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      throw new Error(`Database: ${dbError.message}`);
    }

    console.log('Order saved to database:', order);

    // Prepare email content
    const itemsList = orderData.items
      .map((item: any) => `${item.quantity}x ${item.product.weight} - ₹${item.product.price * item.quantity}`)
      .join('\n');

    const emailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #166534; border-bottom: 3px solid #d4af37; padding-bottom: 10px;">
          🌾 New Order Received - Mithila House
        </h2>
        
        <div style="background: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #166534;">Order Details</h3>
          <p><strong>Order ID:</strong> ${orderData.id}</p>
          <p><strong>Order Date:</strong> ${new Date(orderData.orderDate).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
        </div>

        <div style="background: #fff; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #166534;">Customer Information</h3>
          <p><strong>Name:</strong> ${orderData.customerName}</p>
          <p><strong>Phone:</strong> ${orderData.phone}</p>
          <p><strong>Address:</strong> ${orderData.address}</p>
        </div>

        <div style="background: #fff; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px; margin: 20px 0;">
          <h3 style="margin-top: 0; color: #166534;">Items Ordered</h3>
          <pre style="font-family: monospace; background: #f9fafb; padding: 15px; border-radius: 4px;">${itemsList}</pre>
          <p style="font-size: 18px; font-weight: bold; color: #d4af37; margin-top: 15px;">
            Total Amount: ₹${orderData.totalAmount}
          </p>
          <p style="color: #666;"><strong>Payment:</strong> Cash on Delivery</p>
          <p style="color: #666;"><strong>Delivery Time:</strong> ${orderData.deliveryTime}</p>
        </div>

        <div style="background: #166534; color: white; padding: 15px; border-radius: 8px; text-align: center;">
          <p style="margin: 0;">Login to your admin dashboard to manage this order</p>
        </div>
      </div>
    `;

    // Send email notification
    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: 'Mithila House <orders@onspace.ai>',
        to: [OWNER_EMAIL],
        subject: `🌾 New Order #${orderData.id} - ₹${orderData.totalAmount}`,
        html: emailHtml,
      }),
    });

    if (!emailResponse.ok) {
      const emailError = await emailResponse.text();
      console.error('Email error:', emailError);
      // Don't fail the order if email fails
      console.log('Order saved but email notification failed');
    } else {
      const emailData = await emailResponse.json();
      console.log('Email sent successfully:', emailData);
    }

    return new Response(
      JSON.stringify({ success: true, order }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error processing order:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
