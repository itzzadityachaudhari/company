import { MapPin, Phone, Clock } from 'lucide-react';
import { COMPANY_INFO } from '@/constants/products';

export function Footer() {
  return (
    <footer className="border-t bg-secondary/30 mt-16">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-2xl">🌾</span>
              </div>
              <h3 className="text-lg font-bold text-primary">Mithila House</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Premium quality Makhana (Fox Nuts) delivered fresh to your doorstep in Patna.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
                <span className="text-muted-foreground">{COMPANY_INFO.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                <a 
                  href={`tel:+91${COMPANY_INFO.phone}`}
                  className="text-muted-foreground hover:text-primary transition-colors"
                >
                  +91 {COMPANY_INFO.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                <span className="text-muted-foreground">Delivery: Within {COMPANY_INFO.deliveryTime}</span>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Why Choose Us</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="text-gold">✓</span> 100% Natural & Premium Quality
              </li>
              <li className="flex items-center gap-2">
                <span className="text-gold">✓</span> Fast 4-Hour Delivery
              </li>
              <li className="flex items-center gap-2">
                <span className="text-gold">✓</span> Cash on Delivery Available
              </li>
              <li className="flex items-center gap-2">
                <span className="text-gold">✓</span> Bulk Orders for Shops
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© 2025 Mithila House. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
