import { ShoppingCart, Phone, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCartStore } from '@/stores/cartStore';
import { COMPANY_INFO } from '@/constants/products';
import { useNavigate, useLocation } from 'react-router-dom';

export function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const totalItems = useCartStore((state) => state.getTotalItems());
  
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container flex h-16 items-center justify-between">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-2 group"
        >
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-2xl">🌾</span>
          </div>
          <div className="text-left">
            <h1 className="text-xl font-bold text-primary group-hover:text-primary/80 transition-colors">
              Mithila House
            </h1>
            <p className="text-xs text-muted-foreground">Premium Makhana</p>
          </div>
        </button>
        
        <div className="flex items-center gap-4">
          <a 
            href={`tel:+91${COMPANY_INFO.phone}`}
            className="hidden md:flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <Phone className="h-4 w-4" />
            <span className="font-medium">{COMPANY_INFO.phone}</span>
          </a>
          
          {location.pathname !== '/cart' && (
            <Button 
              onClick={() => navigate('/cart')}
              variant="outline" 
              size="sm"
              className="relative"
            >
              <ShoppingCart className="h-4 w-4 md:mr-2" />
              <span className="hidden md:inline">Cart</span>
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center font-semibold">
                  {totalItems}
                </span>
              )}
            </Button>
          )}
          
          {location.pathname !== '/orders' && (
            <Button 
              onClick={() => navigate('/orders')}
              variant="ghost" 
              size="sm"
            >
              Orders
            </Button>
          )}
          
          {!location.pathname.startsWith('/admin') && (
            <Button 
              onClick={() => navigate('/admin/login')}
              variant="ghost" 
              size="sm"
              className="hidden md:flex"
            >
              <ShieldCheck className="h-4 w-4 mr-2" />
              Owner
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
