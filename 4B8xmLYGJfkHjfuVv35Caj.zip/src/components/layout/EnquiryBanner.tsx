import { Phone } from 'lucide-react';

export function EnquiryBanner() {
  return (
    <div className="bg-primary text-primary-foreground py-2 text-center text-sm font-medium">
      <div className="container flex items-center justify-center gap-2">
        <Phone className="h-4 w-4" />
        <span>For enquiry call on</span>
        <a 
          href="tel:+919534832250" 
          className="font-bold hover:underline"
        >
          9534832250
        </a>
      </div>
    </div>
  );
}
