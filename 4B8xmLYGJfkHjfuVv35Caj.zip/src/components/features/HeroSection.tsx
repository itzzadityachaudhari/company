import { Clock, Truck, Package } from 'lucide-react';
import { PRODUCT_BENEFITS } from '@/constants/products';

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-secondary/30 to-gold/5 border-b-4 border-gold/20">
      <div className="absolute inset-0 bg-ornamental-pattern"></div>
      
      <div className="container relative py-16 md:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 text-center lg:text-left">
            <div className="inline-block">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gold/10 border border-gold/20 text-gold font-semibold text-sm">
                <span className="text-lg">✨</span> Premium Quality Guaranteed
              </span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
              Premium <span className="text-primary">Makhana</span>
              <br />
              <span className="text-gold">Delivered Fresh</span>
            </h1>
            
            <p className="text-lg text-muted-foreground max-w-xl text-balance">
              Experience the finest quality Fox Nuts (Makhana) from Mithila House. 
              Perfect for individuals and bulk orders for shops.
            </p>
            
            <div className="flex flex-wrap gap-6 justify-center lg:justify-start">
              {PRODUCT_BENEFITS.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2 bg-white px-4 py-2 rounded-lg shadow-sm border">
                  <span className="text-2xl">{benefit.icon}</span>
                  <span className="font-semibold text-sm">{benefit.label}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <div className="relative aspect-square max-w-md mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 to-primary/20 rounded-full blur-3xl"></div>
              <img
                src="https://cdn-ai.onspace.ai/onspace/project/uploads/9TgQF9d42LJcpyfuG5GwGz/ChatGPT_Image_Dec_25,_2025,_09_31_14_PM.png"
                alt="Mithila House Premium Makhana Package"
                className="relative w-full h-full object-contain drop-shadow-2xl"
              />
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6 mt-16 max-w-4xl mx-auto">
          <div className="bg-white rounded-xl p-6 shadow-md border-2 border-primary/10 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-bold text-lg mb-2">4-Hour Delivery</h3>
            <p className="text-sm text-muted-foreground">Fast delivery across Patna</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-md border-2 border-gold/20 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package className="h-6 w-6 text-gold" />
            </div>
            <h3 className="font-bold text-lg mb-2">Bulk Orders</h3>
            <p className="text-sm text-muted-foreground">Special pricing for shops</p>
          </div>
          
          <div className="bg-white rounded-xl p-6 shadow-md border-2 border-primary/10 text-center hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Truck className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-bold text-lg mb-2">Cash on Delivery</h3>
            <p className="text-sm text-muted-foreground">Pay when you receive</p>
          </div>
        </div>
      </div>
    </section>
  );
}
