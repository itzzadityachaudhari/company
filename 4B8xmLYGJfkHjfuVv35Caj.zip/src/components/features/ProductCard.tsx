import { useState } from 'react';
import { Minus, Plus, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Product } from '@/types';
import { useCartStore } from '@/stores/cartStore';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((state) => state.addItem);
  const { toast } = useToast();
  
  const handleAddToCart = () => {
    addItem(product, quantity);
    toast({
      title: 'Added to cart',
      description: `${quantity} × ${product.weight} added successfully`,
    });
    setQuantity(1);
  };
  
  return (
    <Card className="relative overflow-hidden group hover:shadow-lg transition-all duration-300 border-2">
      {product.popular && (
        <div className="absolute top-3 right-3 z-10">
          <span className="bg-gold text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md">
            Popular
          </span>
        </div>
      )}
      
      <div className="p-6 space-y-4">
        <div className="text-center space-y-2">
          <div className="text-5xl mb-2">🌰</div>
          <h3 className="text-2xl font-bold text-primary">{product.weight}</h3>
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-3xl font-bold text-gold">₹{product.price}</span>
          </div>
          <p className="text-sm text-muted-foreground">
            ₹{(product.price / product.weightGrams * 1000).toFixed(0)}/kg
          </p>
        </div>
        
        <div className="flex items-center justify-center gap-3">
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-full"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </Button>
          
          <span className="text-lg font-semibold w-12 text-center">
            {quantity}
          </span>
          
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9 rounded-full"
            onClick={() => setQuantity(quantity + 1)}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        
        <Button 
          onClick={handleAddToCart}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
          size="lg"
        >
          <ShoppingCart className="mr-2 h-4 w-4" />
          Add to Cart
        </Button>
      </div>
    </Card>
  );
}
