export interface Product {
  id: string;
  weight: string;
  weightGrams: number;
  price: number;
  popular?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  customerName: string;
  phone: string;
  address: string;
  totalAmount: number;
  orderDate: Date;
  deliveryTime: string;
  status: 'pending' | 'confirmed' | 'delivered';
}

export interface CheckoutFormData {
  name: string;
  phone: string;
  address: string;
}
