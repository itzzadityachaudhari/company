import { useNavigate } from 'react-router-dom';
import { Package, Clock, MapPin, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useOrderStore } from '@/stores/orderStore';

export function OrdersPage() {
  const navigate = useNavigate();
  const orders = useOrderStore((state) => state.orders);
  
  if (orders.length === 0) {
    return (
      <div className="container py-16">
        <Card className="max-w-md mx-auto p-12 text-center">
          <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">No orders yet</h2>
          <p className="text-muted-foreground mb-6">
            Start shopping for premium Makhana!
          </p>
          <Button onClick={() => navigate('/')}>
            Browse Products
          </Button>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Order History</h1>
      
      <div className="space-y-6 max-w-4xl">
        {orders.map((order) => (
          <Card key={order.id} className="p-6 hover:shadow-lg transition-shadow">
            <div className="flex flex-col md:flex-row md:items-start gap-6">
              <div className="flex-1 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-primary mb-1">
                      Order #{order.id}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.orderDate).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                    {order.status === 'confirmed' ? '✓ Confirmed' : order.status}
                  </span>
                </div>
                
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3">
                    <Package className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Items</h4>
                      {order.items.map((item) => (
                        <p key={item.product.id} className="text-sm text-muted-foreground">
                          {item.quantity}× {item.product.weight}
                        </p>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Delivery</h4>
                      <p className="text-sm text-muted-foreground">
                        Within {order.deliveryTime}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3 sm:col-span-2">
                    <MapPin className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-sm mb-1">Address</h4>
                      <p className="text-sm text-muted-foreground">
                        {order.address}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:text-right space-y-2 md:min-w-[140px]">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Total</p>
                  <p className="text-2xl font-bold text-gold">₹{order.totalAmount}</p>
                </div>
                <p className="text-xs text-muted-foreground">Cash on Delivery</p>
                <Button 
                  onClick={() => navigate(`/order-confirmation/${order.id}`)}
                  variant="outline"
                  size="sm"
                  className="w-full md:w-auto mt-4"
                >
                  View Details
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
