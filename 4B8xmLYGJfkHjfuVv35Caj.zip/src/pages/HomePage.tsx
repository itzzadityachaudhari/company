import { HeroSection } from '@/components/features/HeroSection';
import { ProductCard } from '@/components/features/ProductCard';
import { PRODUCTS } from '@/constants/products';

export function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      
      <section className="container py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Choose Your <span className="text-primary">Perfect Pack</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Available in multiple sizes for individuals and bulk orders for shops
          </p>
        </div>
        
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 max-w-7xl mx-auto">
          {PRODUCTS.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
      
      <section className="bg-gradient-to-br from-primary to-primary/80 text-white py-16">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-3xl md:text-4xl font-bold">
              Why Mithila House Makhana?
            </h2>
            
            <div className="grid md:grid-cols-2 gap-8 text-left">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <span className="text-2xl">🏆</span> Premium Quality
                </h3>
                <p className="text-white/90">
                  Carefully selected, hand-picked Fox Nuts ensuring the highest quality standards. 
                  Rich in protein, low in calories, and packed with nutrients.
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <span className="text-2xl">🌾</span> Fresh & Natural
                </h3>
                <p className="text-white/90">
                  100% natural, gluten-free, and preservative-free. Perfect healthy snack 
                  for all ages, from kids to elderly.
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <span className="text-2xl">⚡</span> Lightning Fast
                </h3>
                <p className="text-white/90">
                  Get your order delivered within 4 hours anywhere in Patna. 
                  Fresh from our warehouse to your doorstep.
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                  <span className="text-2xl">🏪</span> Bulk Available
                </h3>
                <p className="text-white/90">
                  Special pricing and packaging for shop owners and businesses. 
                  Stock up your inventory with premium quality Makhana.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
