import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { CheckCircle, Package, Clock, MapPin, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useOrderStore } from '@/stores/orderStore';
import { COMPANY_INFO } from '@/constants/products';

export function OrderConfirmationPage() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const order = useOrderStore((state) => 
    orderId ? state.getOrderById(orderId) : undefined
  );
  
  useEffect(() => {
    if (!order) {
      navigate('/orders');
    }
  }, [order, navigate]);
  
  if (!order) {
    return null;
  }
  
  return (
    <div className="container py-8 max-w-3xl">
      <Card className="p-8 md:p-12 text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="h-12 w-12 text-green-600" />
        </div>
        
        <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
        <p className="text-muted-foreground mb-8">
          Thank you for your order. We'll deliver it fresh to your doorstep.
        </p>
        
        <div className="bg-primary/5 rounded-lg p-6 mb-8">
          <div className="text-sm text-muted-foreground mb-1">Order ID</div>
          <div className="text-2xl font-bold text-primary">#{order.id}</div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6 text-left mb-8">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Package className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Order Items</h3>
                {order.items.map((item) => (
                  <div key={item.product.id} className="text-sm text-muted-foreground">
                    {item.quantity}× {item.product.weight} (₹{item.product.price * item.quantity})
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Clock className="h-5 w-5 text-gold" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Delivery Time</h3>
                <p className="text-sm text-muted-foreground">
                  Within {order.deliveryTime}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Ordered on {new Date(order.orderDate).toLocaleString('en-IN')}
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Delivery Address</h3>
                <p className="text-sm text-muted-foreground">{order.address}</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <Phone className="h-5 w-5 text-gold" />
              </div>
              <div>
                <h3 className="font-semibold mb-1">Contact</h3>
                <p className="text-sm text-muted-foreground">{order.phone}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t pt-6 mb-8">
          <div className="flex justify-between items-center text-lg mb-2">
            <span className="font-semibold">Total Amount</span>
            <span className="text-2xl font-bold text-gold">₹{order.totalAmount}</span>
          </div>
          <p className="text-sm text-muted-foreground">Cash on Delivery</p>
        </div>
        
        <div className="bg-secondary/50 rounded-lg p-6 mb-8 text-left">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span className="text-lg">📞</span> Need Help?
          </h3>
          <p className="text-sm text-muted-foreground mb-2">
            Contact us for any queries about your order:
          </p>
          <a 
            href={`tel:+91${COMPANY_INFO.phone}`}
            className="text-primary font-semibold hover:underline"
          >
            +91 {COMPANY_INFO.phone}
          </a>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Button 
            onClick={() => navigate('/')}
            variant="outline"
            className="flex-1"
          >
            Continue Shopping
          </Button>
          <Button 
            onClick={() => navigate('/orders')}
            className="flex-1"
          >
            View Order History
          </Button>
        </div>
      </Card>
    </div>
  );
}
