import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { LogOut, RefreshCw, Package, IndianRupee, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { FunctionsHttpError } from '@supabase/supabase-js';

interface OrderItem {
  product: {
    weight: string;
    price: number;
  };
  quantity: number;
}

interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  items: OrderItem[];
  total_amount: number;
  delivery_time: string;
  status: string;
  order_date: string;
}

export function AdminDashboardPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    const phone = sessionStorage.getItem('admin_phone');
    const password = sessionStorage.getItem('admin_password');

    if (!phone || !password) {
      navigate('/admin/login');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('get-orders', {
        body: { phone, password },
      });

      if (error) {
        let errorMessage = 'Failed to fetch orders';
        if (error instanceof FunctionsHttpError) {
          try {
            const textContent = await error.context?.text();
            const errorData = JSON.parse(textContent || '{}');
            errorMessage = errorData.error || errorMessage;
          } catch {
            errorMessage = error.message || errorMessage;
          }
        }
        throw new Error(errorMessage);
      }

      if (data.success) {
        setOrders(data.orders || []);
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
      if (error.message.includes('Invalid credentials')) {
        handleLogout();
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem('admin_phone');
    sessionStorage.removeItem('admin_password');
    navigate('/admin/login');
  };

  const totalRevenue = orders.reduce((sum, order) => sum + order.total_amount, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-secondary/30 to-gold/5">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-primary mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage all orders from Mithila House</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={fetchOrders} disabled={loading}>
              <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Package className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{orders.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center">
                <IndianRupee className="h-6 w-6 text-gold" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Orders</p>
                <p className="text-2xl font-bold">
                  {orders.filter(o => o.status === 'confirmed').length}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
            <p className="mt-4 text-muted-foreground">Loading orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <Card className="p-12 text-center">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No orders yet</h3>
            <p className="text-muted-foreground">Orders will appear here once customers start placing them</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <Card key={order.id} className="p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold">Order #{order.id}</h3>
                      <Badge variant="secondary">{order.status}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {new Date(order.order_date).toLocaleString('en-IN', { 
                        dateStyle: 'medium', 
                        timeStyle: 'short',
                        timeZone: 'Asia/Kolkata'
                      })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-gold">₹{order.total_amount}</p>
                    <p className="text-sm text-muted-foreground">Cash on Delivery</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mb-4">
                  <div>
                    <h4 className="font-semibold mb-2">Customer Details</h4>
                    <div className="space-y-1 text-sm">
                      <p><span className="text-muted-foreground">Name:</span> {order.customer_name}</p>
                      <p><span className="text-muted-foreground">Phone:</span> {order.customer_phone}</p>
                      <p><span className="text-muted-foreground">Address:</span> {order.customer_address}</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-2">Order Items</h4>
                    <div className="space-y-1 text-sm">
                      {order.items.map((item, idx) => (
                        <p key={idx}>
                          {item.quantity}x {item.product.weight} - ₹{item.product.price * item.quantity}
                        </p>
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      <Clock className="h-3 w-3 inline mr-1" />
                      Delivery: {order.delivery_time}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
