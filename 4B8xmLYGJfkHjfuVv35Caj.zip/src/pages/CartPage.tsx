import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { FunctionsHttpError } from '@supabase/supabase-js';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useCartStore } from '@/stores/cartStore';
import { useOrderStore } from '@/stores/orderStore';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { CheckoutFormData } from '@/types';

export function CartPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const items = useCartStore((state) => state.items);
  const updateQuantity = useCartStore((state) => state.updateQuantity);
  const removeItem = useCartStore((state) => state.removeItem);
  const getTotalAmount = useCartStore((state) => state.getTotalAmount());
  const clearCart = useCartStore((state) => state.clearCart);
  const addOrder = useOrderStore((state) => state.addOrder);
  
  const [formData, setFormData] = useState<CheckoutFormData>({
    name: '',
    phone: '',
    address: '',
  });
  
  const [errors, setErrors] = useState<Partial<CheckoutFormData>>({});
  const [loading, setLoading] = useState(false);
  
  const validateForm = (): boolean => {
    const newErrors: Partial<CheckoutFormData> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^[6-9]\d{9}$/.test(formData.phone.trim())) {
      newErrors.phone = 'Enter valid 10-digit mobile number';
    }
    
    if (!formData.address.trim()) {
      newErrors.address = 'Delivery address is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast({
        title: 'Invalid form',
        description: 'Please fill all required fields correctly',
        variant: 'destructive',
      });
      return;
    }
    
    setLoading(true);
    
    try {
      const orderId = `ORD${Date.now()}`;
      const totalAmount = getTotalAmount;
      
      const orderData = {
        id: orderId,
        items: items,
        customerName: formData.name,
        phone: formData.phone,
        address: formData.address,
        totalAmount,
        orderDate: new Date().toISOString(),
        deliveryTime: '4 hours',
        status: 'confirmed',
      };
      
      // Save to local store first for immediate feedback
      const order = addOrder(items, formData);
      
      // Send to backend
      const { error } = await supabase.functions.invoke('place-order', {
        body: { orderData },
      });
      
      if (error) {
        let errorMessage = 'Failed to place order';
        if (error instanceof FunctionsHttpError) {
          try {
            const textContent = await error.context?.text();
            const errorData = JSON.parse(textContent || '{}');
            errorMessage = errorData.error || errorMessage;
          } catch {
            errorMessage = error.message || errorMessage;
          }
        }
        throw new Error(errorMessage);
      }
      
      clearCart();
      
      toast({
        title: 'Order placed successfully!',
        description: `Order #${order.id} will be delivered in 4 hours`,
      });
      
      navigate(`/order-confirmation/${order.id}`);
    } catch (error: any) {
      toast({
        title: 'Order placement failed',
        description: error.message || 'Please try again',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };
  
  if (items.length === 0) {
    return (
      <div className="container py-16">
        <Card className="max-w-md mx-auto p-12 text-center">
          <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">Your cart is empty</h2>
          <p className="text-muted-foreground mb-6">
            Add some delicious Makhana to get started!
          </p>
          <Button onClick={() => navigate('/')}>
            Browse Products
          </Button>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>
      
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          {items.map((item) => (
            <Card key={item.product.id} className="p-6">
              <div className="flex items-center gap-6">
                <div className="text-5xl">🌰</div>
                
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-primary">
                    {item.product.weight}
                  </h3>
                  <p className="text-muted-foreground">
                    ₹{item.product.price} per pack
                  </p>
                </div>
                
                <div className="flex items-center gap-3">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  
                  <span className="text-lg font-semibold w-8 text-center">
                    {item.quantity}
                  </span>
                  
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="text-right">
                  <p className="text-xl font-bold text-gold">
                    ₹{item.product.price * item.quantity}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeItem(item.product.id)}
                    className="text-destructive hover:text-destructive mt-2"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Remove
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
        
        <div>
          <Card className="p-6 sticky top-20">
            <h2 className="text-xl font-bold mb-6">Checkout Details</h2>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter your name"
                  className={errors.name ? 'border-destructive' : ''}
                />
                {errors.name && (
                  <p className="text-xs text-destructive mt-1">{errors.name}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="10-digit mobile number"
                  maxLength={10}
                  className={errors.phone ? 'border-destructive' : ''}
                />
                {errors.phone && (
                  <p className="text-xs text-destructive mt-1">{errors.phone}</p>
                )}
              </div>
              
              <div>
                <Label htmlFor="address">Delivery Address *</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Enter complete delivery address in Patna"
                  rows={3}
                  className={errors.address ? 'border-destructive' : ''}
                />
                {errors.address && (
                  <p className="text-xs text-destructive mt-1">{errors.address}</p>
                )}
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>₹{getTotalAmount}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Delivery</span>
                  <span className="text-green-600 font-medium">FREE</span>
                </div>
                <div className="flex justify-between text-xl font-bold text-gold pt-2 border-t">
                  <span>Total</span>
                  <span>₹{getTotalAmount}</span>
                </div>
              </div>
              
              <div className="bg-secondary/50 rounded-lg p-4 text-sm">
                <p className="font-semibold mb-1">💵 Cash on Delivery</p>
                <p className="text-muted-foreground">Pay when you receive your order</p>
              </div>
              
              <div className="bg-primary/5 rounded-lg p-4 text-sm">
                <p className="font-semibold mb-1 text-primary">⚡ 4-Hour Delivery</p>
                <p className="text-muted-foreground">Your order will be delivered within 4 hours</p>
              </div>
              
              <Button type="submit" className="w-full" size="lg" disabled={loading}>
                {loading ? 'Placing Order...' : 'Place Order'}
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
