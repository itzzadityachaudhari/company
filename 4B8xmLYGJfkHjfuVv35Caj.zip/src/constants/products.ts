import { Product } from '@/types';

export const PRODUCTS: Product[] = [
  {
    id: '1kg',
    weight: '1 KG',
    weightGrams: 1000,
    price: 1300,
    popular: true,
  },
  {
    id: '750g',
    weight: '750 G',
    weightGrams: 750,
    price: 1000,
  },
  {
    id: '500g',
    weight: '500 G',
    weightGrams: 500,
    price: 750,
    popular: true,
  },
  {
    id: '250g',
    weight: '250 G',
    weightGrams: 250,
    price: 400,
  },
  {
    id: '100g',
    weight: '100 G',
    weightGrams: 100,
    price: 200,
  },
];

export const COMPANY_INFO = {
  name: 'Mithila House',
  address: 'Bhupatipur, Patna 800020',
  phone: '9534832250',
  deliveryTime: '4 hours',
};

export const PRODUCT_BENEFITS = [
  { icon: '🌿', label: '100% Natural' },
  { icon: '💪', label: 'High Protein' },
  { icon: '🚫', label: 'Gluten Free' },
];
