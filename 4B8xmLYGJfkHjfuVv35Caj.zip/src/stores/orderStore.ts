import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Order, CartItem, CheckoutFormData } from '@/types';

interface OrderStore {
  orders: Order[];
  addOrder: (items: CartItem[], formData: CheckoutFormData) => Order;
  getOrderById: (orderId: string) => Order | undefined;
}

export const useOrderStore = create<OrderStore>()(
  persist(
    (set, get) => ({
      orders: [],
      
      addOrder: (items, formData) => {
        const orderId = `ORD${Date.now()}`;
        const totalAmount = items.reduce(
          (total, item) => total + item.product.price * item.quantity,
          0
        );
        
        const order: Order = {
          id: orderId,
          items,
          customerName: formData.name,
          phone: formData.phone,
          address: formData.address,
          totalAmount,
          orderDate: new Date(),
          deliveryTime: '4 hours',
          status: 'confirmed',
        };
        
        set((state) => ({
          orders: [order, ...state.orders],
        }));
        
        return order;
      },
      
      getOrderById: (orderId) => {
        return get().orders.find((order) => order.id === orderId);
      },
    }),
    {
      name: 'mithila-orders-storage',
    }
  )
);
